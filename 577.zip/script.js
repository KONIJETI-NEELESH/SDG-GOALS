const sdg1 = document.querySelector("#sdg1")
const sdg2 = document.querySelector("#sdg2")
const sdg3 = document.querySelector("#sdg3")
const sdg4 = document.querySelector("#sdg4")
const sdg5 = document.querySelector("#sdg5")
const sdg6 = document.querySelector("#sdg6")
const sdg7 = document.querySelector("#sdg7")
const sdg8 = document.querySelector("#sdg8")
const sdg9 = document.querySelector("#sdg9")
const sdg10 = document.querySelector("#sdg10")
const sdg11 = document.querySelector("#sdg11")
const sdg12 = document.querySelector("#sdg12")
const sdg13 = document.querySelector("#sdg13")
const sdg14 = document.querySelector("#sdg14")
const sdg15 = document.querySelector("#sdg15")
const sdg16 = document.querySelector("#sdg16")
const sdg17 = document.querySelector("#sdg17")
const src1 = document.querySelector("#src1")
const src2 = document.querySelector("#src2")
const src = document.querySelector("#src")
sdg1.addEventListener('click',()=>{
    src1.src = "script1.js"
    src2.classList.add("SRC2")
    src2.src=""
})
sdg2.addEventListener("click",()=>{
    src2.src = "script2.js"
    src1.classList.add("SRC1")
    src1.src=""
})
sdg3.addEventListener("click",()=>{
    src.src = "script3.js"
})
sdg4.addEventListener("click",()=>{
    src.src = "script4.js"
})
sdg5.addEventListener("click",()=>{
    src.src = "script5.js"
})
// sdg6.addEventListener("click",()=>{
//     src.src = "script6.js"
// })
// sdg7.addEventListener("click",()=>{
//     src.src = "script7.js"
// })
// sdg8.addEventListener("click",()=>{
//     src.src = "script8.js"
// })
// sdg9.addEventListener("click",()=>{
//     src.src = "script9.js"
// })
// sdg10.addEventListener("click",()=>{
//     src.src = "script10.js"
// })
// sdg11.addEventListener("click",()=>{
//     src.src = "script11.js"
// })
// sdg12.addEventListener("click",()=>{
//     src.src = "script12.js"
// })
// sdg13.addEventListener("click",()=>{
//     src.src = "script13.js"
// })
// sdg14.addEventListener("click",()=>{
//     src.src = "script14.js"
// })
// sdg15.addEventListener("click",()=>{
//     src.src = "script15.js"
// })
// sdg16.addEventListener("click",()=>{
//     src.src = "script16.js"
// })
// sdg17.addEventListener("click",()=>{
//     src.src = "script17.js"
// })